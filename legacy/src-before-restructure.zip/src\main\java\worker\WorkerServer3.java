/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package worker;

// Starts Worker 3 on port 50054 using the shared WorkerServer logic.
public class WorkerServer3 {

    public static void main(String[] args) {
        WorkerServer.main(new String[] {"3", "50054"});
    }
}
