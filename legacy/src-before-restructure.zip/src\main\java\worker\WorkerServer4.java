/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package worker;

// Starts Worker 4 on port 50055 using the shared WorkerServer logic.
public class WorkerServer4 {

    public static void main(String[] args) {
        WorkerServer.main(new String[] {"4", "50055"});
    }
}
